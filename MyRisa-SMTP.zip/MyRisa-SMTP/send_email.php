<?php
require 'vendor/autoload.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$data = json_decode(file_get_contents("php://input"));
$email = $data->email ?? '';
$message = $data->message ?? '';

$mail = new PHPMailer(true);
try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'your@gmail.com'; // GANTI
    $mail->Password   = 'your-app-password'; // GANTI
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('your@gmail.com', 'MyRisa');
    $mail->addAddress($email);
    $mail->Subject = 'Pesan dari MyRisa';
    $mail->Body    = $message;

    $mail->send();
    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $mail->ErrorInfo]);
}
?>
